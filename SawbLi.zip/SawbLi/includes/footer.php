    </main>
    
    <!-- Footer -->
    <footer class="footer">
        <div class="footer-container">
            <div class="logo">SawbLi<span class="dot">.</span></div>
            <div class="footer-links">
                <div class="footer-section">
                    <h4>À Propos</h4>
                    <ul>
                        <li><a href="#">Notre Histoire</a></li>
                        <li><a href="#">Comment ça marche</a></li>
                        <li><a href="#">Carrières</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Pour les Freelancers</h4>
                    <ul>
                        <li><a href="signup.php?type=freelancer">Devenir Freelancer</a></li>
                        <li><a href="#">Trouver des Clients</a></li>
                        <li><a href="#">Guide des Tarifs</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Pour les Clients</h4>
                    <ul>
                        <li><a href="signup.php?type=client">Créer un Compte</a></li>
                        <li><a href="browse_services.php">Trouver un Freelancer</a></li>
                        <li><a href="#">Conseils de Projet</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Support</h4>
                    <ul>
                        <li><a href="#">Aide</a></li>
                        <li><a href="#">Contact</a></li>
                        <li><a href="#">FAQ</a></li>
                    </ul>
                </div>
            </div>
            <div class="social-media">
                <a href="#"><i class="ri-facebook-box-fill"></i></a>
                <a href="#"><i class="ri-twitter-fill"></i></a>
                <a href="#"><i class="ri-instagram-fill"></i></a>
                <a href="#"><i class="ri-linkedin-box-fill"></i></a>
            </div>
            <p class="copyright">© 2025 SawbLi - Tous droits réservés</p>
            <div class="footer-bottom">
                <a href="#">Politique de confidentialité</a>
                <a href="#">Conditions d'utilisation</a>
                <a href="#">Cookies</a>
            </div>
        </div>
    </footer>

    <script src="main.js"></script>
</body>
</html>
