<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>

    <!-- Ajout de Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.0.3/dist/tailwind.min.css" rel="stylesheet">

    <!-- Autres liens ou scripts si nécessaire -->
</head>
    <!-- Contenu de l'admin header ici -->

<body class="bg-gray-100 text-gray-800">
    <header class="bg-white shadow-md">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <h1 class="text-xl font-bold text-blue-600">SawbLi Admin</h1>
            <nav class="flex gap-4">
                <a href="admin_dashboard.php" class="text-gray-700 hover:text-blue-600 font-medium">Tableau de bord</a>
                <a href="admin_users.php" class="text-gray-700 hover:text-blue-600 font-medium">Utilisateurs</a>
                <a href="admin_services.php" class="text-gray-700 hover:text-blue-600 font-medium">Services</a>
                <a href="admin_messages.php" class="text-gray-700 hover:text-blue-600 font-medium">Messages</a>
                <a href="logout.php" class="text-red-500 hover:text-red-600 font-medium">Déconnexion</a>
            </nav>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 py-6">
