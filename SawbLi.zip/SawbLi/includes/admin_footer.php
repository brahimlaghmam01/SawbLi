</main>

<footer class="bg-white shadow-inner mt-10">
    <div class="max-w-7xl mx-auto px-4 py-6 text-center text-sm text-gray-500">
        &copy; <?= date("Y") ?> SawbLi. Tous droits réservés.
    </div>
</footer>
</body>
</html>
