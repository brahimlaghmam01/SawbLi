<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'db.php';
$conn = $pdo;

// Get current user if logged in
$currentUser = null;
if (isset($_SESSION['user_id'])) {
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $currentUser = $stmt->fetch();
}

// Get flash messages
$errorMessage = $_SESSION['error'] ?? null;
$successMessage = $_SESSION['success'] ?? null;

// Clear flash messages
unset($_SESSION['error']);
unset($_SESSION['success']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SawbLi - Plateforme de Freelance Marocaine</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.5.0/fonts/remixicon.css" rel="stylesheet" />
</head>
<body>
    <!-- Flash Messages -->
    <?php if ($errorMessage): ?>
        <div id="error-message" class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
            <span class="block sm:inline"><?= $errorMessage; ?></span>
            <span class="absolute top-0 bottom-0 right-0 px-4 py-3">
                <svg onclick="this.parentElement.parentElement.style.display='none'" class="fill-current h-6 w-6 text-red-500" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                    <title>Fermer</title>
                    <path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"/>
                </svg>
            </span>
        </div>
    <?php endif; ?>

    <?php if ($successMessage): ?>
        <div id="success-message" class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
            <span class="block sm:inline"><?= $successMessage; ?></span>
            <span class="absolute top-0 bottom-0 right-0 px-4 py-3">
                <svg onclick="this.parentElement.parentElement.style.display='none'" class="fill-current h-6 w-6 text-green-500" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                    <title>Fermer</title>
                    <path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"/>
                </svg>
            </span>
        </div>
    <?php endif; ?>

    <!-- Navbar & Header Fixed -->
    <header class="header">
        <div class="logo">SawbLi<span class="dot">.</span></div>
        <input type="text" class="search" placeholder="Quel service recherchez-vous ?" name="q" form="search-form">
        <form id="search-form" action="search.php" method="GET" style="display:none;"></form>
        <nav>
            <a href="index.php">Accueil</a>
            <a href="browse_services.php">Services</a>

            <?php if ($currentUser): ?>
                <?php if ($currentUser['user_type'] === 'freelancer'): ?>
                    <a href="freelancer_dashboard.php">Mon Dashboard</a>
                <?php else: ?>
                    <a href="client_dashboard.php">Mon Dashboard</a>
                <?php endif; ?>

                <!-- Notification Icon with unread messages count -->
                <div class="relative">
                    <a href="received_messages.php" class="text-gray-600 hover:text-blue-600">
                        <i class="ri-notification-2-line text-2xl"></i>
                        <?php
                            $stmt = $conn->prepare("SELECT COUNT(*) FROM messages WHERE receiver_id = ? AND is_read = 0");
                            $stmt->execute([$currentUser['id']]);
                            $unreadCount = $stmt->fetchColumn();
                        ?>
                        <?php if ($unreadCount > 0): ?>
                            <span class="absolute top-0 right-0 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center"><?= $unreadCount ?></span>
                        <?php endif; ?>
                    </a>
                </div>

                <div class="user-dropdown">
                    <a href="#" id="user-btn"><?= htmlspecialchars($currentUser['username']); ?></a>
                    <ul class="user-menu" id="user-menu">
                        <li><a href="profile.php">👤 Mon Profil</a></li>
                        <li><a href="dashboard.php">📊 Dashboard</a></li>
                        <?php if ($currentUser['user_type'] === 'freelancer'): ?>
                            <li><a href="add_service.php">➕ Ajouter un Service</a></li>
                        <?php endif; ?>
                        <li><a href="logout.php">🚪 Déconnexion</a></li>
                    </ul>
                </div>
            <?php else: ?>
                <a href="signup.php?type=freelancer">Devenir freelance</a>
                <a href="#" id="show-login-btn" class="show-login-btn">Se connecter</a>
                <button class="show-signup-btn" id="show-signup-btn">S'inscrire</button>
            <?php endif; ?>
            
            <div class="discover-dropdown">
                <a href="#" id="discover-btn">Découvrir</a>
                <ul class="discover-menu" id="discover-menu">
                    <li><a href="browse_services.php">🛠 Nos Services</a></li>
                    <li><a href="index.php#testimonials">⭐️ Avis Clients</a></li>
                    <li><a href="index.php#why-us">❓ Pourquoi SawbLi</a></li>
                    <li><a href="index.php#stats">📊 Statistiques</a></li>
                </ul>
            </div>
            
            <div class="language-dropdown">
                <a href="#" id="language-btn">Français</a>
                <ul class="language-menu" id="language-menu">
                    <li><a href="?lang=fr">🇫🇷 Français</a></li>
                    <li><a href="?lang=ar">🇲🇦 العربية</a></li>
                    <li><a href="?lang=en">🇬🇧 English</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <!-- Section modale de connexion -->
    <section id="login" class="login" style="display: none;">
        <div class="login-overlay">
            <!-- Bouton pour fermer la section -->
            <button id="close-login-btn" class="close-login-btn">x</button>
            <div class="login-container">
                <h2>Connectez-vous</h2>
                <form id="login-form" method="POST" action="login.php">
                    <div class="form-group">
                        <label for="login-email">Email :</label>
                        <input type="email" name="email" id="login-email" required>
                    </div>
                    <div class="form-group">
                        <label for="login-password">Mot de passe :</label>
                        <input type="password" name="password" id="login-password" required>
                    </div>
                    <button type="submit" class="login-btn">Connexion</button>
                </form>

                <div class="forgot-password">
                    <a href="#">Mot de passe oublié ?</a>
                </div>
                <div class="signup-link">
                    <p>Vous n'avez pas de compte ? <a href="#" id="switch-to-signup">S'inscrire</a></p>
                </div>
            </div>
        </div>
    </section>

    <!-- Section modale d'inscription -->
    <section id="signup" class="signup" style="display: none;">
        <div class="signup-overlay">
            <!-- Bouton pour fermer la section -->
            <button id="close-signup-btn" class="close-signup-btn">x</button>
            <div class="signup-container">
                <h2>Créer un compte</h2>
                <form id="signup-form" method="POST" action="signup.php">
                    <input type="text" name="username" id="signup-name" placeholder="Nom d'utilisateur" required>
                    <input type="text" name="full_name" placeholder="Nom complet" required>
                    <input type="email" name="email" id="signup-email" placeholder="Email" required>
                    <input type="password" name="password" id="signup-password" placeholder="Mot de passe" required>
                    <input type="password" name="confirm_password" placeholder="Confirmer le mot de passe" required>

                    <select name="user_type" required>
                        <option value="">Choisissez un type</option>
                        <option value="client">Client</option>
                        <option value="freelancer">Freelancer</option>
                    </select>

                    <button type="submit">Créer un compte</button>
                </form>

                <div class="login-link">
                    <p>Vous avez déjà un compte ? <a href="#" id="switch-to-login">Se connecter</a></p>
                </div>
            </div>
        </div>
    </section>
    
    <main>
        <!-- Your main content goes here -->
    </main>
</body>
</html>
