<?php
session_start();
require_once 'db.php';
$conn = $pdo;
require_once 'includes/auth.php';

// Check if user is logged in
if (!isset($_SESSION['user_id']) && !isset($_GET['id'])) {
    $_SESSION['error'] = "Vous devez être connecté pour accéder à cette page.";
    header("Location: login.php");
    exit;
}

// Get profile ID (either the logged-in user or the profile being viewed)
$profile_id = isset($_GET['id']) ? intval($_GET['id']) : $_SESSION['user_id'];

// Get user data
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$profile_id]);
$user = $stmt->fetch();

if (!$user) {
    $_SESSION['error'] = "Utilisateur introuvable.";
    header("Location: index.php");
    exit;
}

// Check if this is the logged-in user's profile
$is_own_profile = isset($_SESSION['user_id']) && $_SESSION['user_id'] === $profile_id;

// Get subscription status
$stmt = $conn->prepare("
    SELECT s.plan_type 
    FROM subscriptions s 
    WHERE s.user_id = ? AND s.is_active = TRUE 
    AND (s.end_date IS NULL OR s.end_date > CURRENT_TIMESTAMP)
    ORDER BY s.plan_type DESC
    LIMIT 1
");
$stmt->execute([$profile_id]);
$subscription = $stmt->fetch();
$is_pro = ($subscription && in_array($subscription['plan_type'], ['pro', 'premium']));

// If this is a freelancer, get their services
$services = [];
if ($user['user_type'] === 'freelancer') {
    $stmt = $conn->prepare("
        SELECT s.*, COUNT(p.id) as project_count 
        FROM services s
        LEFT JOIN projects p ON s.id = p.service_id
        WHERE s.user_id = ? AND s.status = 'active'
        GROUP BY s.id
        ORDER BY s.created_at DESC
    ");
    $stmt->execute([$profile_id]);
    $services = $stmt->fetchAll();
}

// Get projects count
$stmt = $conn->prepare("
    SELECT COUNT(*) as count
    FROM projects
    WHERE " . ($user['user_type'] === 'freelancer' ? "freelancer_id" : "client_id") . " = ? AND status = 'completed'
");
$stmt->execute([$profile_id]);
$completed_projects = $stmt->fetch()['count'];

// Get average rating
$stmt = $conn->prepare("
    SELECT AVG(rating) as average, COUNT(*) as count
    FROM reviews
    WHERE reviewee_id = ?
");
$stmt->execute([$profile_id]);
$rating_data = $stmt->fetch();
$avg_rating = $rating_data['average'] ? round($rating_data['average'], 1) : 0;
$rating_count = $rating_data['count'];

// Get recent reviews
$stmt = $conn->prepare("
    SELECT r.*, p.title as project_title, u.username as reviewer_name
    FROM reviews r
    JOIN projects p ON r.project_id = p.id
    JOIN users u ON r.reviewer_id = u.id
    WHERE r.reviewee_id = ?
    ORDER BY r.created_at DESC
    LIMIT 3
");
$stmt->execute([$profile_id]);
$reviews = $stmt->fetchAll();

include 'includes/header.php';
?>

<div class="profile-container">
    <div class="profile-header">
        <!-- Profile image (placeholder if not set) -->
        <div class="profile-image">
            <?php if (!empty($user['profile_picture'])): ?>
                <img src="uploads/profile_pictures/<?= htmlspecialchars_decode($user['profile_picture']) ?>" alt="<?= htmlspecialchars_decode($user['username']) ?>" class="rounded-full w-52 h-52 object-cover border-2 border-gray-300">
            <?php else: ?>
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-32 h-32">
                    <path d="M12 11C14.2091 11 16 9.20914 16 7C16 4.79086 14.2091 3 12 3C9.79086 3 8 4.79086 8 7C8 9.20914 9.79086 11 12 11Z" fill="#8DA9C4"/>
                    <path d="M12 13C7.58172 13 4 16.5817 4 21H20C20 16.5817 16.4183 13 12 13Z" fill="#8DA9C4"/>
                </svg>
            <?php endif; ?>
        </div>

        
        <div class="profile-info">
            <h1 class="profile-name">
                <?= htmlspecialchars_decode($user['full_name']) ?>
                <?php if ($is_pro): ?>
                    <span class="bg-yellow-400 text-xs font-semibold px-2 py-1 rounded-full ml-2">PRO</span>
                <?php endif; ?>
            </h1>
            
            <p class="profile-title">
                <?= $user['user_type'] === 'freelancer' ? 'Freelancer' : 'Client' ?>
                <!-- Display username -->
                <span class="text-gray-500">@<?= htmlspecialchars_decode($user['username']) ?></span>
            </p>
            
            <!-- Ratings display -->
            <?php if ($user['user_type'] === 'freelancer'): ?>
                <div class="flex items-center mt-2">
                    <div class="flex text-yellow-400">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <?php if ($i <= floor($avg_rating)): ?>
                                <span>★</span>
                            <?php elseif ($i - 0.5 <= $avg_rating): ?>
                                <span>★½</span>
                            <?php else: ?>
                                <span>☆</span>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </div>
                    <span class="ml-2 text-gray-700"><?= $avg_rating ?>/5 (<?= $rating_count ?> avis)</span>
                </div>
            <?php endif; ?>
            
            <!-- Contact information -->
            <?php if (!empty($user['email'])): ?>
                <p class="mt-2"><i class="ri-mail-line"></i> <?= htmlspecialchars_decode($user['email']) ?></p>
            <?php endif; ?>
            
            <?php if (!empty($user['phone'])): ?>
                <p><i class="ri-phone-line"></i> <?= htmlspecialchars_decode($user['phone']) ?></p>
            <?php endif; ?>
            
            <!-- Actions -->
            <div class="profile-actions">
                <?php if ($is_own_profile): ?>
                    <a href="edit_profile.php" class="btn btn-primary">Modifier Profil</a>
                    <a href="<?= $user['user_type'] === 'freelancer' ? 'freelancer_dashboard.php' : 'client_dashboard.php' ?>" class="btn btn-secondary">Mon Dashboard</a>
                <?php elseif ($user['user_type'] === 'freelancer'): ?>
                    <a href="contact.php?id=<?= $profile_id ?>" class="btn btn-primary">Contacter</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Profile Details -->
    <div class="profile-details">
        <h3>À propos</h3>
        <?php if (!empty($user['bio'])): ?>
            <p><?= nl2br(htmlspecialchars_decode($user['bio'])) ?></p>
        <?php else: ?>
            <p class="text-gray-500">Aucune biographie disponible.</p>
        <?php endif; ?>
        
        <!-- Stats -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
            <div class="bg-gray-50 p-4 rounded-lg text-center">
                <p class="text-xl font-bold text-primary-600"><?= number_format($completed_projects) ?></p>
                <p class="text-gray-600">Projets complétés</p>
            </div>
            
            <div class="bg-gray-50 p-4 rounded-lg text-center">
                <p class="text-xl font-bold text-primary-600">
                    <?= $user['user_type'] === 'freelancer' ? count($services) : '-' ?>
                </p>
                <p class="text-gray-600">
                    <?= $user['user_type'] === 'freelancer' ? 'Services proposés' : 'Projets commandés' ?>
                </p>
            </div>
            
            <div class="bg-gray-50 p-4 rounded-lg text-center">
                <p class="text-xl font-bold text-primary-600">
                    <?= date('M Y', strtotime($user['created_at'])) ?>
                </p>
                <p class="text-gray-600">Membre depuis</p>
            </div>
        </div>
    </div>
    
    <!-- Services Section (for freelancers) -->
    <?php if ($user['user_type'] === 'freelancer' && !empty($services)): ?>
        <div class="user-services">
            <h3>Services proposés</h3>
            
            <div class="services-list">
                <?php foreach ($services as $service): ?>
                <div class="service-card">
                    <div class="service-card-header">
                        <h3><?= htmlspecialchars_decode($service['title']) ?></h3>
                        <p class="text-sm text-gray-500">Catégorie: <?= htmlspecialchars_decode($service['category']) ?></p>
                    </div>
                    <div class="service-card-body">
                        <p><?= nl2br(htmlspecialchars_decode(substr($service['description'], 0, 100) . (strlen($service['description']) > 100 ? '...' : ''))) ?></p>
                        <p class="mt-2 text-sm"><?= $service['project_count'] ?> projet(s) réalisé(s)</p>
                    </div>
                    <div class="service-card-footer">
                        <span class="service-price"><?= number_format($service['price'], 2) ?> DH</span>
                        <div class="service-actions">
                            <a href="view_service.php?id=<?= $service['id'] ?>" class="btn btn-primary">Détails</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>
    
    <!-- Reviews Section -->
    <?php if (!empty($reviews)): ?>
        <div class="mt-10">
            <h3 class="text-2xl font-bold mb-6">Avis récents</h3>
            
            <div class="space-y-6">
                <?php foreach ($reviews as $review): ?>
                <div class="bg-white p-6 rounded-lg shadow">
                    <div class="flex justify-between items-start">
                        <div>
                            <p class="font-semibold"><?= htmlspecialchars($review['project_title']) ?></p>
                            <p class="text-sm text-gray-500">Par <?= htmlspecialchars($review['reviewer_name']) ?> le <?= date('d/m/Y', strtotime($review['created_at'])) ?></p>
                        </div>
                        <div class="text-yellow-400">
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <?= $i <= $review['rating'] ? '★' : '☆' ?>
                            <?php endfor; ?>
                        </div>
                    </div>
                    <p class="mt-4 italic">"<?= htmlspecialchars($review['comment']) ?>"</p>
                </div>
                <?php endforeach; ?>
            </div>
            
            <?php if ($rating_count > 3): ?>
                <div class="text-center mt-6">
                    <a href="reviews.php?user=<?= $profile_id ?>" class="text-blue-600 hover:underline">Voir tous les avis (<?= $rating_count ?>)</a>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
