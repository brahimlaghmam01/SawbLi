<?php 
include 'db.php';
$conn = $pdo;
include 'includes/header.php'; 
?>
<link rel="stylesheet" href="styles.css">
<!-- Hero Section -->
<div class="hero-right" style="justify-items: center; margin:80px 0 10px 0">
    <video src="IMG/SawbLi.mp4" autoplay loop muted style="width: 80%; border: none; border-radius: 30px;"></video>
</div>

<!-- Hero Section -->
<header class="hero">
    <div class="hero-left">
        <!-- Search Bar -->
        <div class="search-container" id="searchContainer">
            <form action="search.php" method="GET">
                <input type="text" name="q" class="search-bar" style="padding: 10px 100px;" placeholder="Rechercher des freelances, services...">
                <button type="submit" class="search-button" style="size: 15px;"><i class="ri-search-2-line"></i></button>
            </form>
        </div>
        <h2>Travaillez avec les meilleurs freelances marocains 🚀</h2>
        <p>Découvrez des opportunités dans le développement web et le marketing digital.</p>
        <a href="signup.php?type=freelancer" class="cta-btn">Rejoindre en tant que freelance</a>
    </div>
</header>

<!-- Services Section -->
<section id="services" class="services">
    <h3>Nos Services</h3>
    <div class="service-container">
        <button id="prev" class="scroll-btn left">&#10094;</button>
        <div class="service-boxes">
            <?php
            // Fetch categories from database
            $stmt = $conn->query("SELECT * FROM categories ORDER BY name");
            $categories = $stmt->fetchAll();
            
            $icons = [
                'Développement' => 'IMG/dev.png',
                'Marketing Digital' => 'IMG/marketing.png',
                'Graphisme' => 'IMG/graphisme.png',
                'Montage Vidéo' => 'IMG/edit.png',
                'Analyse de Données' => 'IMG/analysis.png',
                'Musique & Voix Off' => 'IMG/voice.png',
                'Rédaction de Scripts' => 'IMG/script.png',
                'Traduction' => 'IMG/translation.png',
                'Cours en Ligne' => 'IMG/cours.png'
            ];
            
            foreach ($categories as $category) {
                $icon = $icons[$category['name']] ?? 'default-icon.png'; // Set a default icon if no match
                
                // Display category with icon
                echo '<a href="browse_services.php?category=' . urlencode($category['name']) . '" class="service-box">';
                echo '<div class="category-icon">';
                echo '<img src="' . $icon . '" alt="' . htmlspecialchars($category['name']) . '" class="category-img">';
                echo '</div>';
                echo '<span>' . htmlspecialchars_decode($category['name']) . '</span>';
                echo '</a>';
            }
            ?>
        </div>
        <button id="next" class="scroll-btn right">&#10095;</button>
    </div>
</section>


<!-- Reviews Section -->
<section id="testimonials" class="testimonials">
    <h3>Avis de nos clients</h3>
    <div class="testimonial-cards">
        <?php
        // Get a few random reviews
        $stmt = $conn->query("
            SELECT r.rating, r.comment, u.full_name, u.user_type 
            FROM reviews r
            JOIN users u ON r.reviewer_id = u.id
            ORDER BY RAND()
            LIMIT 3
        ");
        
        $reviews = $stmt->fetchAll();
        
        if (count($reviews) > 0) {
            foreach ($reviews as $review) {
                echo '<div class="testimonial-card">';
                echo '<p>"' . htmlspecialchars_decode($review['comment']) . '"</p>';
                echo '<span>- ' . htmlspecialchars_decode($review['full_name']) . ', ' . 
                     ($review['user_type'] == 'client' ? 'client' : 'freelancer') . '</span>';
                echo '</div>';
            }
        } else {
            // Default testimonials if no reviews in database
            ?>
            <div class="testimonial-card">
                <p>"SawbLi a transformé ma carrière de freelance ! Les projets sont variés et les clients très
                    satisfaits."</p>
                <span>- Brahim, programmeur</span>
            </div>
            <div class="testimonial-card">
                <p>"Une plateforme simple et efficace pour trouver des freelances de qualité en marketing digital."</p>
                <span>- Lamyae, société de marketing</span>
            </div>
            <?php
        }
        ?>
    </div>
</section>

<!-- Stats Section -->
<section id="stats" class="stats">
    <h3>Statistiques SawbLi</h3>
    <div class="stat-boxes">
        <?php
        // Get actual stats from database
        $projectCount = $conn->query("SELECT COUNT(*) as count FROM projects")->fetch()['count'] ?? 0;
        $freelancerCount = $conn->query("SELECT COUNT(*) as count FROM users WHERE user_type = 'freelancer'")->fetch()['count'] ?? 0;
        $clientCount = $conn->query("SELECT COUNT(*) as count FROM users WHERE user_type = 'client'")->fetch()['count'] ?? 0;
        
        // If stats are too low, use default values
        $projectCount = max($projectCount, 1200);
        $freelancerCount = max($freelancerCount, 300);
        $clientCount = max($clientCount, 500);
        ?>
        <div class="stat-box">
            <h4><?= $projectCount ?>+</h4>
            <p>Projets réalisés</p>
        </div>
        <div class="stat-box">
            <h4><?= $freelancerCount ?>+</h4>
            <p>Indépendants inscrits</p>
        </div>
        <div class="stat-box">
            <h4><?= $clientCount ?>+</h4>
            <p>Clients satisfaits</p>
        </div>
    </div>
</section>

<!-- Call to Action -->
<section id="cta" class="cta">
    <h3>Êtes-vous prêt à devenir freelance ou à embaucher les meilleurs ?</h3>
    <p>Rejoignez SawbLi et commencez votre aventure maintenant !</p>
    <a href="signup.php" class="cta-btn">Rejoignez-nous</a>
</section>

<!-- Why Choose Us Section -->
<section id="why-us" class="why-us">
    <h3>Pourquoi choisir SawbLi ?</h3>
    <div class="reasons">
        <div class="reason-box">
            <h4>Facilité d'utilisation</h4>
            <p>Notre interface est simple et conviviale.</p>
        </div>
        <div class="reason-box">
            <h4>Assistance continue</h4>
            <p>Assistance technique 24h/24 et 7j/7 disponible pour tous les membres.</p>
        </div>
        <div class="reason-box">
            <h4>Haute fiabilité</h4>
            <p>Systèmes de sécurité pour assurer des transactions sécurisées.</p>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
