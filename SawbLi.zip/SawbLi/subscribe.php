<?php
session_start();
require_once 'db.php';
$conn = $pdo;
require_once 'includes/auth.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = "Vous devez être connecté pour accéder à cette page.";
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Get user information
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) {
    $_SESSION['error'] = "Utilisateur introuvable.";
    header("Location: dashboard.php");
    exit;
}

// Check if plan parameter is provided
if (!isset($_GET['plan']) || !in_array($_GET['plan'], ['pro', 'premium'])) {
    $_SESSION['error'] = "Plan d'abonnement invalide.";
    header("Location: " . ($user['user_type'] === 'freelancer' ? 'freelancer_dashboard.php' : 'client_dashboard.php'));
    exit;
}

$plan = $_GET['plan'];
$plan_name = $plan === 'pro' ? 'Pro' : 'Premium';
$plan_price = $plan === 'pro' ? 99 : 199;

// Check if user already has an active subscription
$stmt = $conn->prepare("
    SELECT * FROM subscriptions 
    WHERE user_id = ? AND is_active = TRUE 
    AND (end_date IS NULL OR end_date > CURRENT_TIMESTAMP)
    ORDER BY plan_type DESC
    LIMIT 1
");
$stmt->execute([$user_id]);
$current_subscription = $stmt->fetch();

// Process subscription payment
$error = '';
$success = '';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['confirm_subscription'])) {
    $card_number = sanitize($_POST['card_number'] ?? '');
    $card_name = sanitize($_POST['card_name'] ?? '');
    $expiry_date = sanitize($_POST['expiry_date'] ?? '');
    $cvv = sanitize($_POST['cvv'] ?? '');
    
    // Basic validation
    if (empty($card_number) || empty($card_name) || empty($expiry_date) || empty($cvv)) {
        $error = "Tous les champs sont requis.";
    } elseif (strlen($card_number) < 16 || !is_numeric($card_number)) {
        $error = "Numéro de carte invalide.";
    } elseif (strlen($cvv) < 3 || !is_numeric($cvv)) {
        $error = "CVV invalide.";
    } else {
        try {
            // In a real application, you would process payment through a payment gateway here
            
            // Set end date for any existing active subscriptions
            $stmt = $conn->prepare("
                UPDATE subscriptions 
                SET is_active = FALSE, end_date = CURRENT_TIMESTAMP
                WHERE user_id = ? AND is_active = TRUE
            ");
            $stmt->execute([$user_id]);
            
            // Create new subscription with 30 days validity
            $stmt = $conn->prepare("
                INSERT INTO subscriptions (user_id, plan_type, start_date, end_date, is_active) 
                VALUES (?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP + INTERVAL '30 days', TRUE)
            ");
            $stmt->execute([$user_id, $plan]);
            
            // Update user pro status
            $stmt = $conn->prepare("UPDATE users SET is_pro = TRUE WHERE id = ?");
            $stmt->execute([$user_id]);
            
            $_SESSION['success'] = "Félicitations ! Votre abonnement SawbLi $plan_name a été activé avec succès.";
            header("Location: " . ($user['user_type'] === 'freelancer' ? 'freelancer_dashboard.php' : 'client_dashboard.php'));
            exit;
        } catch (PDOException $e) {
            $error = "Erreur lors de l'activation de l'abonnement: " . $e->getMessage();
        }
    }
}

include 'includes/header.php';
?>

<div class="form-container">
    <h2>S'abonner à SawbLi <?= $plan_name ?></h2>
    
    <?php if (!empty($error)): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
            <p><?= $error ?></p>
        </div>
    <?php endif; ?>
    
    <?php if ($current_subscription): ?>
        <div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-4" role="alert">
            <p>
                Vous avez déjà un abonnement <?= ucfirst($current_subscription['plan_type']) ?> actif 
                jusqu'au <?= date('d/m/Y', strtotime($current_subscription['end_date'])) ?>.
                En souscrivant à un nouvel abonnement, votre abonnement actuel sera remplacé.
            </p>
        </div>
    <?php endif; ?>
    
    <div class="bg-blue-50 p-6 rounded-lg mb-6">
        <h3 class="text-xl font-bold mb-4">Détails de l'abonnement</h3>
        <ul class="space-y-2">
            <?php if ($plan === 'pro'): ?>
                <li><i class="ri-check-line text-green-600 mr-2"></i> Services illimités</li>
                <li><i class="ri-check-line text-green-600 mr-2"></i> Visibilité accrue</li>
                <li><i class="ri-check-line text-green-600 mr-2"></i> Badge Pro</li>
                <li><i class="ri-check-line text-green-600 mr-2"></i> Support prioritaire</li>
            <?php else: ?>
                <li><i class="ri-check-line text-green-600 mr-2"></i> Tous les avantages Pro</li>
                <li><i class="ri-check-line text-green-600 mr-2"></i> Mise en avant sur la page d'accueil</li>
                <li><i class="ri-check-line text-green-600 mr-2"></i> Analyse de profil</li>
            <?php endif; ?>
        </ul>
        <p class="mt-4 font-bold">Prix: <?= $plan_price ?> DH / mois</p>
    </div>
    
    <form method="POST" action="subscribe.php?plan=<?= $plan ?>">
        <h3 class="text-xl font-bold mb-4">Informations de paiement</h3>
        
        <div class="form-group">
            <label for="card_number">Numéro de carte</label>
            <input type="text" id="card_number" name="card_number" placeholder="1234 5678 9012 3456" maxlength="16" required>
        </div>
        
        <div class="form-group">
            <label for="card_name">Nom sur la carte</label>
            <input type="text" id="card_name" name="card_name" placeholder="John Doe" required>
        </div>
        
        <div class="form-grid">
            <div class="form-group">
                <label for="expiry_date">Date d'expiration</label>
                <input type="text" id="expiry_date" name="expiry_date" placeholder="MM/YY" maxlength="5" required>
            </div>
            
            <div class="form-group">
                <label for="cvv">CVV</label>
                <input type="text" id="cvv" name="cvv" placeholder="123" maxlength="4" required>
            </div>
        </div>
        
        <div class="mt-6 text-sm text-gray-600">
            <p>En cliquant sur "Confirmer l'abonnement", vous acceptez les <a href="#" class="text-blue-600 hover:underline">conditions d'utilisation</a> et la <a href="#" class="text-blue-600 hover:underline">politique de confidentialité</a> de SawbLi.</p>
            <p class="mt-2">Votre abonnement sera automatiquement renouvelé chaque mois. Vous pouvez annuler à tout moment.</p>
        </div>
        
        <div class="form-buttons mt-6">
            <a href="<?= $user['user_type'] === 'freelancer' ? 'freelancer_dashboard.php' : 'client_dashboard.php' ?>" class="btn btn-secondary">Annuler</a>
            <button type="submit" name="confirm_subscription" class="btn btn-primary">Confirmer l'abonnement</button>
        </div>
    </form>
</div>

<?php include 'includes/footer.php'; ?>
