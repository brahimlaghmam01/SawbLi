<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Dashboard Freelancer - SawbLi</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-50 text-gray-800">

  <!-- Header -->
  <header class="bg-white shadow">
    <div class="max-w-7xl mx-auto px-4 py-6 flex justify-between items-center">
      <h1 class="text-2xl font-bold text-indigo-600">SawbLi</h1>
      <nav class="space-x-4">
        <a href="#" class="text-gray-600 hover:text-indigo-600">Accueil</a>
        <a href="#" class="text-gray-600 hover:text-indigo-600">Projets</a>
        <a href="#" class="text-gray-600 hover:text-indigo-600">Messages</a>
        <a href="#" class="text-gray-600 hover:text-indigo-600">Profil</a>
        <a href="#abonnement" class="bg-yellow-400 text-gray-800 font-semibold px-4 py-2 rounded-xl hover:bg-yellow-500 transition">Devenir Pro</a>
      </nav>
    </div>
  </header>

  <!-- Hero -->
  <section class="bg-white py-12 text-center">
    <div class="max-w-3xl mx-auto">
      <h2 class="text-3xl font-bold mb-3">Bienvenue sur votre tableau de bord, Freelancer !</h2>
      <p class="text-gray-600">Gérez vos services, communiquez avec les clients, et développez votre activité.</p>
    </div>
  </section>

  <!-- Services -->
  <section class="py-16 bg-gray-50">
    <div class="max-w-7xl mx-auto px-4">
      <h3 class="text-2xl font-bold mb-6">Vos Services</h3>
      <div class="grid md:grid-cols-3 gap-6">
        <div class="bg-white p-6 rounded-lg shadow">
          <h4 class="font-semibold text-lg mb-2">Développement Web</h4>
          <p class="text-gray-600">Créer des sites performants et responsives.</p>
        </div>
        <div class="bg-white p-6 rounded-lg shadow">
          <h4 class="font-semibold text-lg mb-2">Marketing Digital</h4>
          <p class="text-gray-600">Booster votre visibilité en ligne.</p>
        </div>
        <div class="bg-white p-6 rounded-lg shadow">
          <h4 class="font-semibold text-lg mb-2">Design Graphique</h4>
          <p class="text-gray-600">Concevoir des visuels uniques pour vos projets.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- Statistiques -->
  <section class="py-16 bg-white">
    <div class="max-w-6xl mx-auto px-4 text-center">
      <h3 class="text-2xl font-bold mb-10">Vos Statistiques</h3>
      <div class="grid md:grid-cols-3 gap-6">
        <div class="bg-indigo-50 p-6 rounded-lg shadow">
          <p class="text-4xl font-bold text-indigo-600">12</p>
          <p class="text-gray-600">Projets complétés</p>
        </div>
        <div class="bg-indigo-50 p-6 rounded-lg shadow">
          <p class="text-4xl font-bold text-indigo-600">8</p>
          <p class="text-gray-600">Clients satisfaits</p>
        </div>
        <div class="bg-indigo-50 p-6 rounded-lg shadow">
          <p class="text-4xl font-bold text-indigo-600">4.9/5</p>
          <p class="text-gray-600">Évaluation moyenne</p>
        </div>
      </div>
    </div>
  </section>

  <!-- Témoignages -->
  <section class="py-16 bg-gray-50">
    <div class="max-w-4xl mx-auto px-4 text-center">
      <h3 class="text-2xl font-bold mb-10">Témoignages</h3>
      <div class="bg-white p-6 rounded-lg shadow">
        <p class="text-gray-700 italic">"Grâce à SawbLi, j'ai pu trouver des clients fiables et développer mon activité en ligne."</p>
        <p class="mt-4 font-semibold text-indigo-600">— Sarah M., Développeuse Web</p>
      </div>
    </div>
  </section>

  <!-- Abonnement Section -->
  <section id="abonnement" class="py-16 bg-white">
    <div class="max-w-6xl mx-auto px-4 text-center">
      <h3 class="text-2xl font-bold mb-6">Passez à SawbLi Pro</h3>
      <p class="text-gray-600 mb-10">Augmentez votre visibilité, obtenez plus de projets et débloquez des fonctionnalités exclusives.</p>

      <div class="grid md:grid-cols-3 gap-6">
        <!-- Plan Gratuit -->
        <div class="bg-gray-100 p-6 rounded-lg shadow">
          <h4 class="text-lg font-bold mb-4">Gratuit</h4>
          <p class="text-3xl font-bold mb-4">0 DH</p>
          <ul class="text-gray-600 space-y-2 mb-6">
            <li>3 services actifs</li>
            <li>Support de base</li>
          </ul>
          <button class="bg-gray-400 text-white px-4 py-2 rounded cursor-not-allowed">Plan Actuel</button>
        </div>

        <!-- Plan Pro -->
        <div class="bg-yellow-100 p-6 rounded-lg shadow border-2 border-yellow-400">
          <h4 class="text-lg font-bold mb-4">Pro</h4>
          <p class="text-3xl font-bold mb-4">99 DH / mois</p>
          <ul class="text-gray-600 space-y-2 mb-6">
            <li>Services illimités</li>
            <li>Visibilité accrue</li>
            <li>Badge Pro</li>
            <li>Support prioritaire</li>
          </ul>
          <a href="#" class="bg-yellow-400 hover:bg-yellow-500 text-gray-800 font-semibold px-4 py-2 rounded transition">S’abonner</a>
        </div>

        <!-- Plan Premium -->
        <div class="bg-gray-100 p-6 rounded-lg shadow">
          <h4 class="text-lg font-bold mb-4">Premium</h4>
          <p class="text-3xl font-bold mb-4">199 DH / mois</p>
          <ul class="text-gray-600 space-y-2 mb-6">
            <li>Tous les avantages Pro</li>
            <li>Mise en avant sur la page d’accueil</li>
            <li>Analyse de profil</li>
          </ul>
          <a href="#" class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded transition">S’abonner</a>
        </div>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer class="bg-gray-100 py-6 mt-12 text-center text-gray-600 text-sm">
    © 2025 SawbLi. Tous droits réservés.
  </footer>

</body>
</html>
