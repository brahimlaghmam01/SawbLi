<?php
session_start();
require_once 'db.php';
$conn = $pdo;
// Get all categories for filter
$categories = [];
$stmt = $conn->query("SELECT name FROM categories ORDER BY name");
$categories = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Process filters
$category = isset($_GET['category']) ? sanitize($_GET['category']) : '';
$min_price = isset($_GET['min_price']) && is_numeric($_GET['min_price']) ? floatval($_GET['min_price']) : null;
$max_price = isset($_GET['max_price']) && is_numeric($_GET['max_price']) ? floatval($_GET['max_price']) : null;
$sort = isset($_GET['sort']) ? sanitize($_GET['sort']) : 'newest';

// Build query
$query = "
    SELECT s.*, u.username as freelancer_name, u.id as freelancer_id,
           (SELECT AVG(r.rating) FROM reviews r 
            JOIN projects p ON r.project_id = p.id 
            WHERE p.freelancer_id = u.id) as avg_rating,
           (SELECT COUNT(*) FROM projects p WHERE p.service_id = s.id AND p.status = 'completed') as completed_count
    FROM services s
    JOIN users u ON s.user_id = u.id
    WHERE s.status = 'active'
";

$params = [];

// Apply category filter
if (!empty($category)) {
    $query .= " AND s.category = ?";
    $params[] = $category;
}

// Apply price filters
if ($min_price !== null) {
    $query .= " AND s.price >= ?";
    $params[] = $min_price;
}

if ($max_price !== null) {
    $query .= " AND s.price <= ?";
    $params[] = $max_price;
}

// Apply sorting
switch ($sort) {
    case 'price_low':
        $query .= " ORDER BY s.price ASC";
        break;
    case 'price_high':
        $query .= " ORDER BY s.price DESC";
        break;
    case 'rating':
        $query .= " ORDER BY avg_rating DESC";
        break;
    case 'popularity':
        $query .= " ORDER BY completed_count DESC";
        break;
    case 'newest':
    default:
        $query .= " ORDER BY s.created_at DESC";
        break;
}

// Execute query
$stmt = $conn->prepare($query);
$stmt->execute($params);
$services = $stmt->fetchAll();

// Get total count
$total_services = count($services);

include 'includes/header.php';
?>

<div class="container mx-auto px-4 py-8 mt-20">
    <h1 class="text-3xl font-bold mb-4">Parcourir les Services</h1>
    
    <!-- Filter Section -->
    <div class="filter-container">
        <form action="browse_services.php" method="GET" class="filter-form">
            <div class="filter-group">
                <label for="category">Catégorie</label>
                <select id="category" name="category">
                    <option value="">Toutes les catégories</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= htmlspecialchars($cat) ?>" <?= $category === $cat ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="filter-group">
                <label for="min_price">Prix min (DH)</label>
                <input type="number" id="min_price" name="min_price" min="0" step="10" value="<?= $min_price !== null ? $min_price : '' ?>">
            </div>
            
            <div class="filter-group">
                <label for="max_price">Prix max (DH)</label>
                <input type="number" id="max_price" name="max_price" min="0" step="10" value="<?= $max_price !== null ? $max_price : '' ?>">
            </div>
            
            <div class="filter-group">
                <label for="sort">Trier par</label>
                <select id="sort" name="sort">
                    <option value="newest" <?= $sort === 'newest' ? 'selected' : '' ?>>Plus récents</option>
                    <option value="price_low" <?= $sort === 'price_low' ? 'selected' : '' ?>>Prix croissant</option>
                    <option value="price_high" <?= $sort === 'price_high' ? 'selected' : '' ?>>Prix décroissant</option>
                    <option value="rating" <?= $sort === 'rating' ? 'selected' : '' ?>>Meilleures notes</option>
                    <option value="popularity" <?= $sort === 'popularity' ? 'selected' : '' ?>>Popularité</option>
                </select>
            </div>
            
            <div class="filter-group">
                <label style="visibility: hidden;">Filtrer</label>
                <button type="submit" class="btn btn-primary w-full">Appliquer les filtres</button>
            </div>
        </form>
    </div>
    
    <!-- Results Count -->
    <div class="mt-6 mb-4">
        <p><?= $total_services ?> service(s) trouvé(s) <?= !empty($category) ? 'dans ' . htmlspecialchars($category) : '' ?></p>
    </div>
    
    <!-- Services List -->
    <?php if ($total_services > 0): ?>
        <div class="services-list">
            <?php foreach ($services as $service): ?>
                <div class="service-card">
                    <div class="service-card-header">
                        <h3><?= htmlspecialchars($service['title']) ?></h3>
                        <div class="flex justify-between">
                            <span class="text-sm text-gray-500">
                                Par: <a href="profile.php?id=<?= $service['freelancer_id'] ?>" class="text-blue-600 hover:underline">
                                    <?= htmlspecialchars($service['freelancer_name']) ?>
                                </a>
                            </span>
                            
                            <?php if ($service['avg_rating']): ?>
                                <span class="text-yellow-400">
                                    <?php 
                                    $stars = round($service['avg_rating']);
                                    for ($i = 1; $i <= 5; $i++) {
                                        echo $i <= $stars ? '★' : '☆';
                                    }
                                    ?>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="service-card-body">
                        <p><?= nl2br(htmlspecialchars(substr($service['description'], 0, 120) . (strlen($service['description']) > 120 ? '...' : ''))) ?></p>
                        <div class="mt-2 flex items-center text-sm">
                            <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded"><?= htmlspecialchars($service['category']) ?></span>
                            <?php if ($service['completed_count'] > 0): ?>
                                <span class="ml-2 text-gray-600"><?= $service['completed_count'] ?> projet(s) réalisé(s)</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="service-card-footer">
                        <span class="service-price"><?= number_format($service['price'], 2) ?> DH</span>
                        <a href="view_service.php?id=<?= $service['id'] ?>" class="btn btn-primary">Voir détails</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="bg-gray-50 p-8 rounded-lg text-center">
            <p class="text-lg mb-4">Aucun service trouvé avec ces critères.</p>
            <a href="browse_services.php" class="btn btn-primary">Réinitialiser les filtres</a>
        </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
